<?php
/**
 * Plugin Name:       Simple SEO
 * Plugin URI:        https://example.com/simple-seo
 * Description:       A lightweight, production-ready SEO plugin. Zero bloat, maximum impact.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Simple SEO
 * License:           GPL v2 or later
 * Text Domain:       simple-seo
 * Domain Path:       /languages
 *
 * @package SimpleSEO
 */

defined( 'ABSPATH' ) || exit;

// ── Constants ────────────────────────────────────────────────────────────────

define( 'SIMPLE_SEO_VERSION',   '1.0.0' );
define( 'SIMPLE_SEO_FILE',      __FILE__ );
define( 'SIMPLE_SEO_DIR',       plugin_dir_path( __FILE__ ) );
define( 'SIMPLE_SEO_URL',       plugin_dir_url( __FILE__ ) );
define( 'SIMPLE_SEO_SLUG',      'simple-seo' );

// ── Autoloader ───────────────────────────────────────────────────────────────

spl_autoload_register( function ( string $class ): void {
    // Only handle our namespace.
    if ( strpos( $class, 'SimpleSEO_' ) !== 0 ) {
        return;
    }

    $map = [
        // Core
        'SimpleSEO_Loader'   => SIMPLE_SEO_DIR . 'core/class-loader.php',
        'SimpleSEO_Helpers'  => SIMPLE_SEO_DIR . 'core/class-helpers.php',
        'SimpleSEO_Options'  => SIMPLE_SEO_DIR . 'core/class-options.php',
        'SimpleSEO_Install'  => SIMPLE_SEO_DIR . 'core/class-install.php',

        // Modules
        'SimpleSEO_Meta'            => SIMPLE_SEO_DIR . 'modules/meta/class-meta.php',
        'SimpleSEO_Meta_Box'        => SIMPLE_SEO_DIR . 'modules/meta/class-meta-box.php',
        'SimpleSEO_Meta_Analysis'   => SIMPLE_SEO_DIR . 'modules/meta/class-meta-analysis.php',
        'SimpleSEO_OpenGraph'       => SIMPLE_SEO_DIR . 'modules/meta/class-opengraph.php',
        'SimpleSEO_Sitemap'         => SIMPLE_SEO_DIR . 'modules/sitemap/class-sitemap.php',
        'SimpleSEO_Schema'          => SIMPLE_SEO_DIR . 'modules/schema/class-schema.php',
        'SimpleSEO_Robots'          => SIMPLE_SEO_DIR . 'modules/sitemap/class-robots.php',
        'SimpleSEO_Redirect'        => SIMPLE_SEO_DIR . 'modules/redirect/class-redirect.php',
        'SimpleSEO_Redirect_Table'  => SIMPLE_SEO_DIR . 'modules/redirect/class-redirect-table.php',
        'SimpleSEO_Internal_Links'  => SIMPLE_SEO_DIR . 'modules/internal-links/class-internal-links.php',
        'SimpleSEO_Image_SEO'       => SIMPLE_SEO_DIR . 'modules/image-seo/class-image-seo.php',

        // Admin
        'SimpleSEO_Admin'           => SIMPLE_SEO_DIR . 'admin/class-admin.php',
        'SimpleSEO_Admin_Settings'  => SIMPLE_SEO_DIR . 'admin/class-admin-settings.php',
        'SimpleSEO_Admin_Sitemap'   => SIMPLE_SEO_DIR . 'admin/class-admin-sitemap.php',
        'SimpleSEO_Admin_Redirects' => SIMPLE_SEO_DIR . 'admin/class-admin-redirects.php',
    ];

    if ( isset( $map[ $class ] ) && file_exists( $map[ $class ] ) ) {
        require_once $map[ $class ];
    }
} );

// ── Bootstrap ─────────────────────────────────────────────────────────────────

/**
 * Returns the single plugin instance.
 *
 * @return SimpleSEO_Loader
 */
function simple_seo(): SimpleSEO_Loader {
    return SimpleSEO_Loader::instance();
}

// Activation / deactivation hooks must be registered before init.
register_activation_hook(   SIMPLE_SEO_FILE, [ 'SimpleSEO_Install', 'activate' ] );
register_deactivation_hook( SIMPLE_SEO_FILE, [ 'SimpleSEO_Install', 'deactivate' ] );

add_action( 'plugins_loaded', 'simple_seo' );
