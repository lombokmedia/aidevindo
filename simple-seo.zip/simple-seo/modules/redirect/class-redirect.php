<?php
/**
 * Redirect Manager Module.
 *
 * - Listens on template_redirect for matching source paths.
 * - Performs 301 redirects from the custom DB table.
 * - Optionally logs 404 URLs.
 *
 * @package SimpleSEO\Modules\Redirect
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Redirect {

    /** Cache key for redirect map. */
    const CACHE_KEY = 'simple_seo_redirects';

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_action( 'template_redirect', [ $this, 'maybe_redirect' ], 1 );
    }

    // ── Redirect Detection ───────────────────────────────────────────────────

    /**
     * Check current request path against redirect rules and redirect if matched.
     */
    public function maybe_redirect(): void {
        // Normalise the current request path.
        $request = SimpleSEO_Helpers::normalise_path(
            isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '/'
        );

        $redirects = $this->get_redirect_map();

        if ( isset( $redirects[ $request ] ) ) {
            $row  = $redirects[ $request ];
            $code = (int) ( $row['code'] ?? 301 );
            $dest = $row['destination'];

            // Increment hit counter (non-blocking).
            $this->increment_hits( (int) $row['id'] );

            wp_redirect( esc_url_raw( $dest ), $code );
            exit;
        }

        // 404 logging (if enabled and this is actually a 404).
        if ( is_404() && SimpleSEO_Options::get( 'redirect_log_404', true ) ) {
            $this->log_404( $request );
        }
    }

    // ── Redirect Map ─────────────────────────────────────────────────────────

    /**
     * Return all redirects as a source → data array (cached in memory).
     *
     * @return array<string, array{id: int, destination: string, code: int}>
     */
    public function get_redirect_map(): array {
        $cached = wp_cache_get( self::CACHE_KEY, 'simple_seo' );
        if ( false !== $cached ) {
            return $cached;
        }

        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_results( "SELECT id, source, destination, code FROM {$table}", ARRAY_A );

        $map = [];
        foreach ( (array) $rows as $row ) {
            $map[ $row['source'] ] = $row;
        }

        wp_cache_set( self::CACHE_KEY, $map, 'simple_seo', 300 );
        return $map;
    }

    /**
     * Flush the in-memory redirect cache.
     */
    public function flush_cache(): void {
        wp_cache_delete( self::CACHE_KEY, 'simple_seo' );
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    /**
     * Add or update a redirect.
     *
     * @param string $source      Source path (normalised).
     * @param string $destination Destination URL.
     * @param int    $code        HTTP status code (301).
     * @return bool
     */
    public function upsert( string $source, string $destination, int $code = 301 ): bool {
        global $wpdb;

        $source = SimpleSEO_Helpers::normalise_path( $source );
        $table  = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;

        $existing = $wpdb->get_var( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            "SELECT id FROM {$table} WHERE source = %s",
            $source
        ) );

        if ( $existing ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $result = $wpdb->update(
                $table,
                [ 'destination' => $destination, 'code' => $code ],
                [ 'id' => (int) $existing ],
                [ '%s', '%d' ],
                [ '%d' ]
            );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $result = $wpdb->insert(
                $table,
                [ 'source' => $source, 'destination' => $destination, 'code' => $code ],
                [ '%s', '%s', '%d' ]
            );
        }

        $this->flush_cache();
        return false !== $result;
    }

    /**
     * Delete a redirect by ID.
     *
     * @param int $id Redirect row ID.
     * @return bool
     */
    public function delete( int $id ): bool {
        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->delete( $table, [ 'id' => $id ], [ '%d' ] );
        $this->flush_cache();
        return false !== $result;
    }

    /**
     * Return all redirect rows.
     *
     * @param int $per_page Rows per page.
     * @param int $page     1-based page index.
     * @return array<int, array<string,string>>
     */
    public function get_all( int $per_page = 50, int $page = 1 ): array {
        global $wpdb;
        $table  = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;
        $offset = ( $page - 1 ) * $per_page;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (array) $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ), ARRAY_A );
    }

    /**
     * Return total redirect count.
     *
     * @return int
     */
    public function count(): int {
        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    }

    // ── 404 Log ──────────────────────────────────────────────────────────────

    /**
     * Log or increment a 404 URL.
     *
     * @param string $url Request path.
     */
    private function log_404( string $url ): void {
        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_404_LOG;

        // Try to increment existing entry first.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $updated = $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET hits = hits + 1, last_seen = NOW() WHERE url = %s",
            $url
        ) );

        if ( ! $updated ) {
            $referrer = isset( $_SERVER['HTTP_REFERER'] )
                ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) )
                : '';

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->insert(
                $table,
                [ 'url' => $url, 'referrer' => $referrer, 'hits' => 1, 'last_seen' => current_time( 'mysql', true ) ],
                [ '%s', '%s', '%d', '%s' ]
            );
        }
    }

    /**
     * Return recent 404 log entries.
     *
     * @param int $limit Number of rows.
     * @return array<int, array<string,string>>
     */
    public function get_404_log( int $limit = 50 ): array {
        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_404_LOG;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (array) $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY hits DESC LIMIT %d",
            $limit
        ), ARRAY_A );
    }

    // ── Internal ─────────────────────────────────────────────────────────────

    /**
     * Increment hit counter for a redirect row.
     *
     * @param int $id Row ID.
     */
    private function increment_hits( int $id ): void {
        global $wpdb;
        $table = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET hits = hits + 1 WHERE id = %d",
            $id
        ) );
    }
}
