<?php
/**
 * WP_List_Table implementation for the Redirect Manager admin page.
 *
 * @package SimpleSEO\Modules\Redirect
 */

defined( 'ABSPATH' ) || exit;

// Make sure WP_List_Table is loaded (it's not autoloaded in all contexts).
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class SimpleSEO_Redirect_Table extends WP_List_Table {

    public function register_hooks(): void {
        // No hooks needed — instantiated by admin page.
    }

    public function __construct() {
        parent::__construct( [
            'singular' => 'redirect',
            'plural'   => 'redirects',
            'ajax'     => false,
        ] );
    }

    // ── Columns ──────────────────────────────────────────────────────────────

    public function get_columns(): array {
        return [
            'cb'          => '<input type="checkbox" />',
            'source'      => __( 'Source', 'simple-seo' ),
            'destination' => __( 'Destination', 'simple-seo' ),
            'code'        => __( 'Code', 'simple-seo' ),
            'hits'        => __( 'Hits', 'simple-seo' ),
            'created_at'  => __( 'Created', 'simple-seo' ),
        ];
    }

    public function get_sortable_columns(): array {
        return [
            'source'     => [ 'source', false ],
            'hits'       => [ 'hits', true ],
            'created_at' => [ 'created_at', false ],
        ];
    }

    protected function get_bulk_actions(): array {
        return [
            'delete' => __( 'Delete', 'simple-seo' ),
        ];
    }

    // ── Data ─────────────────────────────────────────────────────────────────

    public function prepare_items(): void {
        /** @var SimpleSEO_Redirect $redirect */
        $redirect    = simple_seo()->get( 'redirect' );
        $per_page    = 25;
        $current     = $this->get_pagenum();
        $total_items = $redirect->count();

        $this->items = $redirect->get_all( $per_page, $current );

        $this->set_pagination_args( [
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => (int) ceil( $total_items / $per_page ),
        ] );

        $columns  = $this->get_columns();
        $hidden   = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [ $columns, $hidden, $sortable ];
    }

    // ── Cell rendering ───────────────────────────────────────────────────────

    protected function column_default( $item, $column_name ) {
        return esc_html( $item[ $column_name ] ?? '—' );
    }

    protected function column_cb( $item ) {
        return sprintf( '<input type="checkbox" name="redirect_ids[]" value="%d" />', (int) $item['id'] );
    }

    protected function column_source( $item ) {
        $actions = [
            'edit'   => sprintf(
                '<a href="%s">%s</a>',
                esc_url( add_query_arg( [ 'action' => 'edit', 'redirect_id' => $item['id'] ] ) ),
                esc_html__( 'Edit', 'simple-seo' )
            ),
            'delete' => sprintf(
                '<a href="%s" onclick="return confirm(\'%s\')">%s</a>',
                esc_url( wp_nonce_url(
                    add_query_arg( [ 'action' => 'delete', 'redirect_id' => $item['id'] ] ),
                    'simple_seo_delete_redirect_' . $item['id']
                ) ),
                esc_js( __( 'Delete this redirect?', 'simple-seo' ) ),
                esc_html__( 'Delete', 'simple-seo' )
            ),
        ];

        return '<code>' . esc_html( $item['source'] ) . '</code>' . $this->row_actions( $actions );
    }

    protected function column_destination( $item ) {
        return '<a href="' . esc_url( $item['destination'] ) . '" target="_blank">' . esc_html( $item['destination'] ) . '</a>';
    }
}
