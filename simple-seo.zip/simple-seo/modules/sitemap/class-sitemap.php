<?php
/**
 * XML Sitemap Module.
 *
 * Serves a dynamic /sitemap.xml endpoint.
 * Uses WordPress transients for caching (TTL configurable via options).
 * Automatically invalidates cache on post save/trash/delete.
 *
 * @package SimpleSEO\Modules\Sitemap
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Sitemap {

    /** Transient key for cached sitemap XML. */
    const CACHE_KEY = 'simple_seo_sitemap';

    /** Query var used to detect the sitemap request. */
    const QUERY_VAR = 'simple_seo_sitemap';

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        // Register query var and rewrite rule.
        add_filter( 'query_vars',     [ $this, 'add_query_var' ] );
        add_action( 'init',           [ $this, 'add_rewrite_rule' ] );
        add_action( 'template_redirect', [ $this, 'maybe_serve_sitemap' ] );

        // Invalidate cache when content changes.
        add_action( 'save_post',      [ $this, 'invalidate_cache' ] );
        add_action( 'trashed_post',   [ $this, 'invalidate_cache' ] );
        add_action( 'deleted_post',   [ $this, 'invalidate_cache' ] );
        add_action( 'created_term',   [ $this, 'invalidate_cache' ] );
        add_action( 'edited_term',    [ $this, 'invalidate_cache' ] );
        add_action( 'deleted_term',   [ $this, 'invalidate_cache' ] );
    }

    // ── Rewrite ──────────────────────────────────────────────────────────────

    public function add_query_var( array $vars ): array {
        $vars[] = self::QUERY_VAR;
        return $vars;
    }

    public function add_rewrite_rule(): void {
        add_rewrite_rule( '^sitemap\.xml$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
    }

    // ── Serve ────────────────────────────────────────────────────────────────

    /**
     * Detect the sitemap query var and serve the XML response.
     */
    public function maybe_serve_sitemap(): void {
        if ( ! get_query_var( self::QUERY_VAR ) ) {
            return;
        }

        $xml = $this->get_sitemap_xml();

        // Output XML and exit.
        if ( ! headers_sent() ) {
            header( 'Content-Type: application/xml; charset=UTF-8' );
            header( 'X-Robots-Tag: noindex, follow' );
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XML is pre-built and escaped.
        echo $xml;
        exit;
    }

    // ── Build ─────────────────────────────────────────────────────────────────

    /**
     * Return sitemap XML, using the transient cache when available.
     *
     * @return string Valid XML string.
     */
    public function get_sitemap_xml(): string {
        $cached = get_transient( self::CACHE_KEY );
        if ( false !== $cached ) {
            return $cached;
        }

        $xml = $this->build_sitemap();
        $ttl = (int) SimpleSEO_Options::get( 'sitemap_cache_ttl', 3600 );
        set_transient( self::CACHE_KEY, $xml, $ttl );

        return $xml;
    }

    /**
     * Build the full sitemap XML string.
     *
     * @return string
     */
    private function build_sitemap(): string {
        $urls = [];

        // Home page.
        $urls[] = [
            'loc'        => home_url( '/' ),
            'lastmod'    => gmdate( 'Y-m-d' ),
            'changefreq' => 'daily',
            'priority'   => '1.0',
        ];

        // Posts and custom post types.
        $urls = array_merge( $urls, $this->get_post_urls() );

        // Taxonomy terms.
        $urls = array_merge( $urls, $this->get_term_urls() );

        /**
         * Filter sitemap URL entries before rendering.
         *
         * Each entry: [ loc, lastmod, changefreq, priority ]
         *
         * @param array<int, array<string,string>> $urls URL entries.
         */
        $urls = (array) apply_filters( 'simple_seo_sitemap_urls', $urls );

        return $this->render_xml( $urls );
    }

    /**
     * Collect URLs for all public post types.
     *
     * @return array<int, array<string,string>>
     */
    private function get_post_urls(): array {
        $allowed_types = (array) SimpleSEO_Options::get( 'sitemap_post_types', [ 'post', 'page' ] );
        $urls          = [];

        $posts = get_posts( [
            'post_type'      => $allowed_types,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ] );

        foreach ( $posts as $post_id ) {
            $permalink = get_permalink( $post_id );
            if ( ! $permalink ) {
                continue;
            }

            $modified = get_post_modified_time( 'Y-m-d', true, $post_id );
            $type     = get_post_type( $post_id );
            $priority = ( 'page' === $type ) ? '0.8' : '0.6';

            $urls[] = [
                'loc'        => $permalink,
                'lastmod'    => $modified ?: gmdate( 'Y-m-d' ),
                'changefreq' => ( 'post' === $type ) ? 'weekly' : 'monthly',
                'priority'   => $priority,
            ];
        }

        return $urls;
    }

    /**
     * Collect URLs for taxonomy terms.
     *
     * @return array<int, array<string,string>>
     */
    private function get_term_urls(): array {
        $allowed_taxes = (array) SimpleSEO_Options::get( 'sitemap_taxonomies', [ 'category', 'post_tag' ] );
        $urls          = [];

        $terms = get_terms( [
            'taxonomy'   => $allowed_taxes,
            'hide_empty' => true,
            'fields'     => 'all',
        ] );

        if ( is_wp_error( $terms ) ) {
            return $urls;
        }

        foreach ( $terms as $term ) {
            $link = get_term_link( $term );
            if ( is_wp_error( $link ) ) {
                continue;
            }
            $urls[] = [
                'loc'        => $link,
                'lastmod'    => gmdate( 'Y-m-d' ),
                'changefreq' => 'weekly',
                'priority'   => '0.5',
            ];
        }

        return $urls;
    }

    /**
     * Render URL entries as an XML sitemap string.
     *
     * @param array<int, array<string,string>> $urls URL entries.
     * @return string
     */
    private function render_xml( array $urls ): string {
        $out  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $out .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach ( $urls as $entry ) {
            $out .= "\t<url>\n";
            $out .= "\t\t<loc>" . esc_url( $entry['loc'] ) . "</loc>\n";

            if ( ! empty( $entry['lastmod'] ) ) {
                $out .= "\t\t<lastmod>" . esc_html( $entry['lastmod'] ) . "</lastmod>\n";
            }
            if ( ! empty( $entry['changefreq'] ) ) {
                $out .= "\t\t<changefreq>" . esc_html( $entry['changefreq'] ) . "</changefreq>\n";
            }
            if ( ! empty( $entry['priority'] ) ) {
                $out .= "\t\t<priority>" . esc_html( $entry['priority'] ) . "</priority>\n";
            }
            $out .= "\t</url>\n";
        }

        $out .= '</urlset>';
        return $out;
    }

    // ── Cache Invalidation ───────────────────────────────────────────────────

    /**
     * Delete the cached sitemap transient.
     */
    public function invalidate_cache(): void {
        delete_transient( self::CACHE_KEY );
    }
}
