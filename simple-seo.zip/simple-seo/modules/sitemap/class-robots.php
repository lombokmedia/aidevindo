<?php
/**
 * Dynamic robots.txt Module.
 *
 * Hooks into WordPress's `robots_txt` filter to inject:
 *  - Sitemap URL
 *  - Disallow wp-admin (for all bots)
 *  - Allow admin-ajax.php (for AJAX-heavy themes)
 *
 * @package SimpleSEO\Modules\Sitemap
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Robots {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_filter( 'robots_txt', [ $this, 'filter_robots_txt' ], 20, 2 );
    }

    // ── Filter ───────────────────────────────────────────────────────────────

    /**
     * Append Simple SEO rules to the robots.txt output.
     *
     * @param string $output  Current robots.txt content.
     * @param bool   $public  Whether the site is set to public.
     * @return string
     */
    public function filter_robots_txt( string $output, bool $public ): string {
        if ( ! $public ) {
            // Site is not set to public; leave robots.txt as-is.
            return $output;
        }

        $sitemap_url = home_url( '/sitemap.xml' );

        $rules  = "\n# Simple SEO\n";
        $rules .= "User-agent: *\n";
        $rules .= "Disallow: /wp-admin/\n";
        $rules .= "Allow: /wp-admin/admin-ajax.php\n";
        $rules .= "\n";
        $rules .= "Sitemap: " . esc_url_raw( $sitemap_url ) . "\n";

        /**
         * Filter the robots.txt rules added by Simple SEO.
         *
         * @param string $rules      Rules to append.
         * @param string $output     Existing robots.txt content.
         * @param string $sitemap_url Sitemap URL.
         */
        $rules = (string) apply_filters( 'simple_seo_robots_rules', $rules, $output, $sitemap_url );

        return $output . $rules;
    }
}
