<?php
/**
 * Internal Linking Module.
 *
 * - Scans posts for focus keywords and suggests relevant internal links.
 * - Optional: auto-insert links on the_content filter (configurable limit per post).
 *
 * @package SimpleSEO\Modules\InternalLinks
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Internal_Links {

    /** Cache key prefix for link suggestions. */
    const CACHE_PREFIX = 'simple_seo_ilinks_';

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        // Auto-link (optional, off by default).
        if ( SimpleSEO_Options::get( 'auto_link_enabled', false ) ) {
            add_filter( 'the_content', [ $this, 'auto_insert_links' ], 20 );
        }
    }

    // ── Suggestions ──────────────────────────────────────────────────────────

    /**
     * Return internal link suggestions for a given post.
     *
     * Finds other published posts whose focus keyword appears in $post_id's content.
     *
     * @param int $post_id Source post ID.
     * @return array<int, array{post_id: int, title: string, url: string, keyword: string}>
     */
    public function get_suggestions( int $post_id ): array {
        $cache_key = self::CACHE_PREFIX . $post_id;
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return [];
        }

        $content = wp_strip_all_tags( $post->post_content );

        // Fetch all posts with a focus keyword set (excluding current).
        $candidates = get_posts( [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'post__not_in'   => [ $post_id ],
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery
                [
                    'key'     => SimpleSEO_Meta::META_KEYWORD,
                    'value'   => '',
                    'compare' => '!=',
                ],
            ],
        ] );

        $suggestions = [];

        foreach ( $candidates as $candidate_id ) {
            $keyword = (string) get_post_meta( $candidate_id, SimpleSEO_Meta::META_KEYWORD, true );
            if ( '' === $keyword ) {
                continue;
            }

            if ( false !== mb_stripos( $content, $keyword ) ) {
                $suggestions[] = [
                    'post_id' => $candidate_id,
                    'title'   => get_the_title( $candidate_id ),
                    'url'     => (string) get_permalink( $candidate_id ),
                    'keyword' => $keyword,
                ];
            }
        }

        set_transient( $cache_key, $suggestions, HOUR_IN_SECONDS );
        return $suggestions;
    }

    // ── Auto-insertion ────────────────────────────────────────────────────────

    /**
     * Automatically insert internal links into post content.
     *
     * Respects the `auto_link_per_post` limit.
     * Skips keywords that already have a link in the content.
     *
     * @param string $content Post content HTML.
     * @return string Modified content.
     */
    public function auto_insert_links( string $content ): string {
        if ( ! is_singular() ) {
            return $content;
        }

        $post_id = get_queried_object_id();
        $limit   = (int) SimpleSEO_Options::get( 'auto_link_per_post', 3 );

        $suggestions = $this->get_suggestions( $post_id );
        if ( empty( $suggestions ) ) {
            return $content;
        }

        $inserted = 0;

        foreach ( $suggestions as $suggestion ) {
            if ( $inserted >= $limit ) {
                break;
            }

            $keyword = $suggestion['keyword'];
            $url     = $suggestion['url'];

            // Only link the keyword if it is not already inside an anchor tag.
            $link    = '<a href="' . esc_url( $url ) . '">' . esc_html( $keyword ) . '</a>';
            $pattern = '/(?<![\'">])(' . preg_quote( $keyword, '/' ) . ')(?![^<]*<\/a>)/i';

            $new_content = preg_replace( $pattern, $link, $content, 1 );

            if ( $new_content !== $content ) {
                $content = $new_content;
                $inserted++;
            }
        }

        return $content;
    }

    /**
     * Invalidate the suggestion cache for a post.
     *
     * Called externally when post meta changes.
     *
     * @param int $post_id Post ID.
     */
    public function invalidate_cache( int $post_id ): void {
        delete_transient( self::CACHE_PREFIX . $post_id );
    }
}
