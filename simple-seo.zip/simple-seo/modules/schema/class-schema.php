<?php
/**
 * Schema (JSON-LD) Module.
 *
 * Outputs structured data in <head>:
 *  - Article schema for singular posts.
 *  - Organization schema on all pages.
 *  - BreadcrumbList schema on singular and archive pages.
 *
 * @package SimpleSEO\Modules\Schema
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Schema {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        if ( ! SimpleSEO_Options::get( 'schema_enabled', true ) ) {
            return;
        }

        add_action( 'wp_head', [ $this, 'output_schema' ], 10 );
    }

    // ── Output ───────────────────────────────────────────────────────────────

    /**
     * Collect and output all relevant schema blocks.
     */
    public function output_schema(): void {
        if ( is_admin() || is_feed() ) {
            return;
        }

        $schemas = [];

        // Organization schema — always present.
        $org = $this->build_organization();
        if ( $org ) {
            $schemas[] = $org;
        }

        // Article schema — singular posts.
        if ( is_singular( 'post' ) ) {
            $article = $this->build_article( get_queried_object_id() );
            if ( $article ) {
                $schemas[] = $article;
            }
        }

        // Breadcrumb schema.
        $breadcrumb = $this->build_breadcrumb();
        if ( $breadcrumb ) {
            $schemas[] = $breadcrumb;
        }

        if ( empty( $schemas ) ) {
            return;
        }

        /**
         * Filter schema output array before printing.
         *
         * @param array<int, array<string,mixed>> $schemas Array of schema objects.
         * @param int                              $post_id Queried object ID.
         */
        $schemas = (array) apply_filters( 'simple_seo_schema_output', $schemas, get_queried_object_id() );

        echo "\n<!-- Simple SEO: Schema -->\n";
        foreach ( $schemas as $schema ) {
            // wp_json_encode handles escaping; no additional escaping needed.
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>' . "\n";
        }
        echo "<!-- / Simple SEO: Schema -->\n\n";
    }

    // ── Builders ─────────────────────────────────────────────────────────────

    /**
     * Build Organization schema.
     *
     * @return array<string,mixed>|null
     */
    private function build_organization(): ?array {
        $name = (string) SimpleSEO_Options::get( 'org_name', get_bloginfo( 'name' ) );
        $url  = (string) SimpleSEO_Options::get( 'org_url',  home_url() );
        $logo = (string) SimpleSEO_Options::get( 'org_logo', '' );

        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            'name'     => $name,
            'url'      => $url,
        ];

        if ( $logo ) {
            $schema['logo'] = [
                '@type' => 'ImageObject',
                'url'   => $logo,
            ];
        }

        return $schema;
    }

    /**
     * Build Article schema for a post.
     *
     * @param int $post_id Post ID.
     * @return array<string,mixed>|null
     */
    private function build_article( int $post_id ): ?array {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return null;
        }

        /** @var SimpleSEO_Meta $meta_module */
        $meta_module = simple_seo()->get( 'meta' );
        $headline    = $meta_module ? $meta_module->get_title() : get_the_title( $post_id );
        $description = $meta_module ? $meta_module->get_description() : '';

        $schema = [
            '@context'         => 'https://schema.org',
            '@type'            => 'Article',
            'headline'         => $headline,
            'description'      => $description,
            'url'              => (string) get_permalink( $post_id ),
            'datePublished'    => get_the_date( 'c', $post_id ),
            'dateModified'     => get_the_modified_date( 'c', $post_id ),
            'author'           => [
                '@type' => 'Person',
                'name'  => get_the_author_meta( 'display_name', (int) $post->post_author ),
            ],
            'publisher'        => [
                '@type' => 'Organization',
                'name'  => (string) SimpleSEO_Options::get( 'org_name', get_bloginfo( 'name' ) ),
                'url'   => (string) SimpleSEO_Options::get( 'org_url',  home_url() ),
            ],
        ];

        // Featured image.
        $img = SimpleSEO_Helpers::get_post_image( $post_id );
        if ( $img ) {
            $schema['image'] = [
                '@type' => 'ImageObject',
                'url'   => $img,
            ];
        }

        return $schema;
    }

    /**
     * Build BreadcrumbList schema for the current page.
     *
     * @return array<string,mixed>|null
     */
    private function build_breadcrumb(): ?array {
        $items = [];
        $pos   = 1;

        // Home item.
        $items[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => __( 'Home', 'simple-seo' ),
            'item'     => home_url( '/' ),
        ];

        if ( is_singular() ) {
            $post_id    = get_queried_object_id();
            $post_type  = get_post_type( $post_id );

            // For posts, add the first category if present.
            if ( 'post' === $post_type ) {
                $cats = get_the_category( $post_id );
                if ( ! empty( $cats ) ) {
                    $items[] = [
                        '@type'    => 'ListItem',
                        'position' => $pos++,
                        'name'     => $cats[0]->name,
                        'item'     => (string) get_term_link( $cats[0] ),
                    ];
                }
            }

            $items[] = [
                '@type'    => 'ListItem',
                'position' => $pos++,
                'name'     => get_the_title( $post_id ),
                'item'     => (string) get_permalink( $post_id ),
            ];
        } elseif ( is_tax() || is_category() || is_tag() ) {
            $term    = get_queried_object();
            $items[] = [
                '@type'    => 'ListItem',
                'position' => $pos++,
                'name'     => $term->name ?? '',
                'item'     => (string) get_term_link( $term ),
            ];
        }

        if ( count( $items ) <= 1 ) {
            // Only home = not very useful, skip.
            return null;
        }

        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $items,
        ];
    }
}
