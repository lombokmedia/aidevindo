<?php
/**
 * Image SEO Module.
 *
 * - Automatically adds ALT text to images missing it (uses post/attachment title).
 * - Provides a bulk-fixer admin action.
 *
 * @package SimpleSEO\Modules\ImageSEO
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Image_SEO {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        if ( SimpleSEO_Options::get( 'image_auto_alt', true ) ) {
            // Filter image HTML on the front end.
            add_filter( 'the_content',    [ $this, 'auto_add_alt_in_content' ], 15 );
            // Filter attachment metadata on upload.
            add_filter( 'attachment_fields_to_save', [ $this, 'maybe_set_alt_on_save' ], 10, 2 );
        }
    }

    // ── Content filter ───────────────────────────────────────────────────────

    /**
     * Scan post content HTML and add ALT attributes to <img> tags that lack them.
     *
     * @param string $content Post content HTML.
     * @return string Modified content.
     */
    public function auto_add_alt_in_content( string $content ): string {
        if ( ! is_singular() ) {
            return $content;
        }

        // Match <img> tags that have no alt attribute, or have alt="".
        $content = preg_replace_callback(
            '/<img([^>]*?)>/i',
            function ( array $matches ) {
                $tag   = $matches[0];
                $attrs = $matches[1];

                // Already has a non-empty alt.
                if ( preg_match( '/\balt=["\']([^"\']+)["\']/', $attrs ) ) {
                    return $tag;
                }

                // Extract src to find attachment.
                if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/', $attrs, $src_match ) ) {
                    return $tag;
                }

                $alt = $this->get_alt_for_src( $src_match[1] );
                if ( '' === $alt ) {
                    return $tag;
                }

                // Inject or replace alt attribute.
                if ( preg_match( '/\balt=["\']["\']/', $attrs ) ) {
                    // Empty alt="" — replace it.
                    $new_attrs = preg_replace( '/\balt=["\']["\']/', 'alt="' . esc_attr( $alt ) . '"', $attrs );
                } else {
                    // No alt — append it.
                    $new_attrs = $attrs . ' alt="' . esc_attr( $alt ) . '"';
                }

                return '<img' . $new_attrs . '>';
            },
            $content
        );

        return $content ?? '';
    }

    /**
     * Derive ALT text for an image URL.
     *
     * Tries: attachment alt meta → attachment title → filename.
     *
     * @param string $src Image URL.
     * @return string
     */
    private function get_alt_for_src( string $src ): string {
        // Try to match the URL to an attachment.
        $attachment_id = $this->get_attachment_id_by_url( $src );

        if ( $attachment_id ) {
            $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
            if ( $alt ) {
                return (string) $alt;
            }
            return (string) get_the_title( $attachment_id );
        }

        // Fallback: derive from filename.
        $filename = pathinfo( wp_parse_url( $src, PHP_URL_PATH ) ?? '', PATHINFO_FILENAME );
        return sanitize_title( $filename );
    }

    /**
     * Look up an attachment ID from an image URL.
     *
     * @param string $url Image URL.
     * @return int 0 if not found.
     */
    private function get_attachment_id_by_url( string $url ): int {
        global $wpdb;

        // Strip query strings and size suffixes (e.g. -300x200).
        $url = preg_replace( '/(-\d+x\d+)(\.[a-z]+)$/i', '$2', strtok( $url, '?' ) ?? '' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $id = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE guid = %s AND post_type = 'attachment' LIMIT 1",
            $url
        ) );

        return (int) $id;
    }

    // ── On Upload ────────────────────────────────────────────────────────────

    /**
     * Set ALT text when an attachment is saved without one.
     *
     * @param array<string,mixed> $post       Attachment post data.
     * @param array<string,mixed> $attachment Attachment fields.
     * @return array<string,mixed>
     */
    public function maybe_set_alt_on_save( array $post, array $attachment ): array {
        if ( ! empty( $attachment['image_alt'] ) ) {
            return $post;
        }

        // Use the attachment title.
        $title = sanitize_text_field( $post['post_title'] ?? '' );
        if ( $title ) {
            update_post_meta( (int) $post['ID'], '_wp_attachment_image_alt', $title );
        }

        return $post;
    }

    // ── Bulk Fixer ───────────────────────────────────────────────────────────

    /**
     * Bulk-fix ALT text for all attachments that are missing it.
     *
     * Returns the number of attachments updated.
     *
     * @return int
     */
    public function bulk_fix_alt(): int {
        $attachments = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery
                'relation' => 'OR',
                [
                    'key'     => '_wp_attachment_image_alt',
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key'     => '_wp_attachment_image_alt',
                    'value'   => '',
                    'compare' => '=',
                ],
            ],
        ] );

        $count = 0;
        foreach ( $attachments as $id ) {
            $title = get_the_title( $id );
            if ( $title ) {
                update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
                $count++;
            }
        }

        return $count;
    }
}
