<?php
/**
 * Post editor meta box for Simple SEO.
 *
 * Adds a "Simple SEO" box to the post editor with:
 *  - Focus keyword
 *  - Custom meta title
 *  - Custom meta description
 *  - Google SERP preview
 *
 * @package SimpleSEO\Modules\Meta
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Meta_Box {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_action( 'add_meta_boxes',  [ $this, 'add_meta_box' ] );
        add_action( 'save_post',       [ $this, 'save_meta_box' ], 10, 2 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    // ── Meta Box Registration ────────────────────────────────────────────────

    /**
     * Register the meta box on all public post types.
     */
    public function add_meta_box(): void {
        $post_types = get_post_types( [ 'public' => true ] );

        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'simple-seo-meta',
                __( 'Simple SEO', 'simple-seo' ),
                [ $this, 'render_meta_box' ],
                $post_type,
                'normal',
                'high'
            );
        }
    }

    // ── Render ───────────────────────────────────────────────────────────────

    /**
     * Render the meta box HTML.
     *
     * @param WP_Post $post Current post object.
     */
    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'simple_seo_meta_box_' . $post->ID, '_simple_seo_nonce' );

        $keyword  = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_KEYWORD,     true );
        $title    = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_TITLE,       true );
        $desc     = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_DESCRIPTION, true );

        // Computed fallbacks for the live preview.
        $pattern        = SimpleSEO_Options::get( 'title_pattern_post' );
        $fallback_title = SimpleSEO_Helpers::parse_tokens( $pattern, [
            'title'     => get_the_title( $post->ID ),
            'site_name' => get_bloginfo( 'name' ),
        ] );

        $fallback_desc = SimpleSEO_Helpers::truncate(
            $post->post_excerpt ?: $post->post_content,
            (int) SimpleSEO_Options::get( 'meta_desc_length', 160 )
        );
        ?>
        <div id="simple-seo-meta-box">

            <?php /* ── Focus Keyword ─────────────────────────────────── */ ?>
            <div class="sseo-field">
                <label for="sseo-keyword">
                    <strong><?php esc_html_e( 'Focus Keyword', 'simple-seo' ); ?></strong>
                </label>
                <input
                    type="text"
                    id="sseo-keyword"
                    name="simple_seo_keyword"
                    value="<?php echo esc_attr( $keyword ); ?>"
                    placeholder="<?php esc_attr_e( 'Primary keyword for this page…', 'simple-seo' ); ?>"
                    class="widefat"
                />
            </div>

            <?php /* ── Meta Title ───────────────────────────────────── */ ?>
            <div class="sseo-field">
                <label for="sseo-title">
                    <strong><?php esc_html_e( 'Meta Title', 'simple-seo' ); ?></strong>
                    <span class="sseo-counter" id="sseo-title-counter">0 / 60</span>
                </label>
                <input
                    type="text"
                    id="sseo-title"
                    name="simple_seo_title"
                    value="<?php echo esc_attr( $title ); ?>"
                    placeholder="<?php echo esc_attr( $fallback_title ); ?>"
                    maxlength="70"
                    class="widefat"
                    data-fallback="<?php echo esc_attr( $fallback_title ); ?>"
                />
                <p class="description">
                    <?php esc_html_e( 'Leave blank to use the auto-generated title.', 'simple-seo' ); ?>
                </p>
            </div>

            <?php /* ── Meta Description ──────────────────────────────── */ ?>
            <div class="sseo-field">
                <label for="sseo-description">
                    <strong><?php esc_html_e( 'Meta Description', 'simple-seo' ); ?></strong>
                    <span class="sseo-counter" id="sseo-desc-counter">0 / 160</span>
                </label>
                <textarea
                    id="sseo-description"
                    name="simple_seo_description"
                    rows="3"
                    maxlength="170"
                    class="widefat"
                    placeholder="<?php echo esc_attr( $fallback_desc ); ?>"
                    data-fallback="<?php echo esc_attr( $fallback_desc ); ?>"
                ><?php echo esc_textarea( $desc ); ?></textarea>
                <p class="description">
                    <?php esc_html_e( 'Recommended: 120–160 characters.', 'simple-seo' ); ?>
                </p>
            </div>

            <?php /* ── Google SERP Preview ──────────────────────────── */ ?>
            <div class="sseo-preview">
                <p><strong><?php esc_html_e( 'Google Preview', 'simple-seo' ); ?></strong></p>
                <div class="sseo-serp">
                    <div class="sseo-serp-url"><?php echo esc_url( get_permalink( $post->ID ) ); ?></div>
                    <div class="sseo-serp-title" id="sseo-preview-title">
                        <?php echo esc_html( $title ?: $fallback_title ); ?>
                    </div>
                    <div class="sseo-serp-desc" id="sseo-preview-desc">
                        <?php echo esc_html( $desc ?: $fallback_desc ); ?>
                    </div>
                </div>
            </div>

        </div><!-- #simple-seo-meta-box -->
        <?php
    }

    // ── Save ─────────────────────────────────────────────────────────────────

    /**
     * Persist meta box values.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     */
    public function save_meta_box( int $post_id, WP_Post $post ): void {
        // Autosave / bulk-edit guards.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( 'auto-draft' === $post->post_status ) {
            return;
        }

        // Nonce check.
        $nonce = isset( $_POST['_simple_seo_nonce'] )
            ? sanitize_text_field( wp_unslash( $_POST['_simple_seo_nonce'] ) )
            : '';

        if ( ! wp_verify_nonce( $nonce, 'simple_seo_meta_box_' . $post_id ) ) {
            return;
        }

        // Capability check.
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save keyword.
        $keyword = isset( $_POST['simple_seo_keyword'] )
            ? sanitize_text_field( wp_unslash( $_POST['simple_seo_keyword'] ) )
            : '';
        update_post_meta( $post_id, SimpleSEO_Meta::META_KEYWORD, $keyword );

        // Save title.
        $title = isset( $_POST['simple_seo_title'] )
            ? sanitize_text_field( wp_unslash( $_POST['simple_seo_title'] ) )
            : '';
        update_post_meta( $post_id, SimpleSEO_Meta::META_TITLE, $title );

        // Save description.
        $desc = isset( $_POST['simple_seo_description'] )
            ? sanitize_textarea_field( wp_unslash( $_POST['simple_seo_description'] ) )
            : '';
        update_post_meta( $post_id, SimpleSEO_Meta::META_DESCRIPTION, $desc );
    }

    // ── Assets ───────────────────────────────────────────────────────────────

    /**
     * Enqueue meta box styles and vanilla JS.
     *
     * @param string $hook_suffix Current admin page.
     */
    public function enqueue_assets( string $hook_suffix ): void {
        if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
            return;
        }

        wp_enqueue_style(
            'simple-seo-meta-box',
            SIMPLE_SEO_URL . 'admin/css/meta-box.css',
            [],
            SIMPLE_SEO_VERSION
        );

        wp_enqueue_script(
            'simple-seo-meta-box',
            SIMPLE_SEO_URL . 'admin/js/meta-box.js',
            [],
            SIMPLE_SEO_VERSION,
            true
        );
    }
}
