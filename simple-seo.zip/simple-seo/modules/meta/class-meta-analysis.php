<?php
/**
 * SEO Analysis Module.
 *
 * Renders a lightweight checklist in the post editor (no scoring colours,
 * just pass/fail items per the spec).
 *
 * Checks performed:
 *  1. Title length (30–60 chars)
 *  2. Description length (120–160 chars)
 *  3. Focus keyword present in title
 *  4. Focus keyword present in content
 *  5. At least one internal link in content
 *
 * @package SimpleSEO\Modules\Meta
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Meta_Analysis {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_action( 'add_meta_boxes', [ $this, 'add_analysis_box' ] );
    }

    // ── Meta Box ─────────────────────────────────────────────────────────────

    public function add_analysis_box(): void {
        $post_types = get_post_types( [ 'public' => true ] );
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'simple-seo-analysis',
                __( 'SEO Analysis', 'simple-seo' ),
                [ $this, 'render_analysis_box' ],
                $post_type,
                'side',
                'default'
            );
        }
    }

    public function render_analysis_box( WP_Post $post ): void {
        $checks  = $this->run_checks( $post );
        $passed  = array_filter( $checks, fn( $c ) => $c['pass'] );
        $total   = count( $checks );
        $p_count = count( $passed );
        ?>
        <div id="sseo-analysis">
            <p class="sseo-analysis-score">
                <?php
                /* translators: 1: passed checks 2: total checks */
                printf( esc_html__( '%1$d / %2$d checks passed', 'simple-seo' ), $p_count, $total );
                ?>
            </p>
            <ul class="sseo-checklist">
                <?php foreach ( $checks as $check ) : ?>
                    <li class="sseo-check-<?php echo $check['pass'] ? 'pass' : 'fail'; ?>">
                        <span class="sseo-check-icon"><?php echo $check['pass'] ? '✓' : '✗'; ?></span>
                        <?php echo esc_html( $check['label'] ); ?>
                        <?php if ( ! empty( $check['hint'] ) ) : ?>
                            <span class="sseo-hint"> — <?php echo esc_html( $check['hint'] ); ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
    }

    // ── Analysis Logic ───────────────────────────────────────────────────────

    /**
     * Run all checks against the given post.
     *
     * @param WP_Post $post Post object.
     * @return array<int, array{label: string, pass: bool, hint: string}>
     */
    private function run_checks( WP_Post $post ): array {
        $checks = [];

        // Retrieve stored meta.
        $keyword  = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_KEYWORD,     true );
        $meta_title = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_TITLE,     true );
        $meta_desc  = (string) get_post_meta( $post->ID, SimpleSEO_Meta::META_DESCRIPTION, true );

        // Effective title (override or generated).
        $pattern  = SimpleSEO_Options::get( 'title_pattern_post' );
        $eff_title = $meta_title ?: SimpleSEO_Helpers::parse_tokens( $pattern, [
            'title'     => get_the_title( $post->ID ),
            'site_name' => get_bloginfo( 'name' ),
        ] );

        // Effective description.
        $eff_desc = $meta_desc ?: SimpleSEO_Helpers::truncate(
            $post->post_excerpt ?: $post->post_content,
            160
        );

        $title_len = mb_strlen( $eff_title );
        $desc_len  = mb_strlen( $eff_desc );

        // ── Check 1: Title length ────────────────────────────────────────────
        $checks[] = [
            'label' => __( 'Title length', 'simple-seo' ),
            'pass'  => $title_len >= 30 && $title_len <= 60,
            'hint'  => sprintf(
                /* translators: %d: current length */
                __( '%d chars (ideal: 30–60)', 'simple-seo' ),
                $title_len
            ),
        ];

        // ── Check 2: Description length ──────────────────────────────────────
        $checks[] = [
            'label' => __( 'Description length', 'simple-seo' ),
            'pass'  => $desc_len >= 120 && $desc_len <= 160,
            'hint'  => sprintf(
                /* translators: %d: current length */
                __( '%d chars (ideal: 120–160)', 'simple-seo' ),
                $desc_len
            ),
        ];

        // ── Check 3: Keyword in title ────────────────────────────────────────
        if ( $keyword ) {
            $checks[] = [
                'label' => __( 'Focus keyword in title', 'simple-seo' ),
                'pass'  => $this->contains_keyword( $eff_title, $keyword ),
                'hint'  => '',
            ];

            // ── Check 4: Keyword in content ──────────────────────────────────
            $checks[] = [
                'label' => __( 'Focus keyword in content', 'simple-seo' ),
                'pass'  => $this->contains_keyword( $post->post_content, $keyword ),
                'hint'  => '',
            ];
        } else {
            $checks[] = [
                'label' => __( 'Focus keyword set', 'simple-seo' ),
                'pass'  => false,
                'hint'  => __( 'Add a focus keyword above', 'simple-seo' ),
            ];
        }

        // ── Check 5: Internal links ──────────────────────────────────────────
        $internal_links = $this->count_internal_links( $post->post_content );
        $checks[]       = [
            'label' => __( 'Internal links', 'simple-seo' ),
            'pass'  => $internal_links >= 1,
            'hint'  => sprintf(
                /* translators: %d: link count */
                __( '%d found', 'simple-seo' ),
                $internal_links
            ),
        ];

        return $checks;
    }

    /**
     * Case-insensitive keyword check.
     *
     * @param string $haystack Text to search in.
     * @param string $keyword  Keyword to look for.
     * @return bool
     */
    private function contains_keyword( string $haystack, string $keyword ): bool {
        return false !== mb_stripos( wp_strip_all_tags( $haystack ), $keyword );
    }

    /**
     * Count internal links in post content.
     *
     * @param string $content Post content HTML.
     * @return int
     */
    private function count_internal_links( string $content ): int {
        $home    = home_url();
        $pattern = '/<a\s[^>]*href=[\'"](' . preg_quote( $home, '/' ) . '[^\'"]*)[\'"][^>]*>/i';
        preg_match_all( $pattern, $content, $matches );
        return count( $matches[0] );
    }
}
