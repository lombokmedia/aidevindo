<?php
/**
 * Open Graph & Twitter Cards Module.
 *
 * Outputs og:* and twitter:* meta tags in <head>.
 * Can be globally toggled via options.
 *
 * @package SimpleSEO\Modules\Meta
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_OpenGraph {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        if ( SimpleSEO_Options::get( 'og_enabled' ) ) {
            add_action( 'wp_head', [ $this, 'output_opengraph' ], 5 );
        }

        if ( SimpleSEO_Options::get( 'twitter_cards_enabled' ) ) {
            add_action( 'wp_head', [ $this, 'output_twitter_cards' ], 6 );
        }
    }

    // ── Open Graph ───────────────────────────────────────────────────────────

    /**
     * Output Open Graph tags.
     */
    public function output_opengraph(): void {
        $data = $this->build_og_data();
        if ( empty( $data ) ) {
            return;
        }

        echo "\n<!-- Simple SEO: Open Graph -->\n";

        foreach ( $data as $property => $content ) {
            if ( '' === $content ) {
                continue;
            }
            printf(
                '<meta property="%s" content="%s">' . "\n",
                esc_attr( $property ),
                esc_attr( $content )
            );
        }

        echo "<!-- / Simple SEO: Open Graph -->\n\n";
    }

    /**
     * Build the array of og: property => value pairs.
     *
     * @return array<string,string>
     */
    private function build_og_data(): array {
        // We only output OG tags on singular pages and archives.
        if ( is_admin() || is_feed() ) {
            return [];
        }

        // Get meta from the Meta module.
        /** @var SimpleSEO_Meta $meta */
        $meta  = simple_seo()->get( 'meta' );
        $title = $meta ? $meta->get_title()       : get_the_title();
        $desc  = $meta ? $meta->get_description() : '';

        $og = [
            'og:type'        => is_singular() ? 'article' : 'website',
            'og:title'       => $title,
            'og:description' => $desc,
            'og:url'         => is_singular() ? (string) get_permalink() : (string) home_url( add_query_arg( [] ) ),
            'og:site_name'   => get_bloginfo( 'name' ),
        ];

        // Image.
        if ( is_singular() ) {
            $img = SimpleSEO_Helpers::get_post_image( get_queried_object_id() );
        } else {
            $img = (string) SimpleSEO_Options::get( 'og_default_image', '' );
        }

        if ( $img ) {
            $og['og:image'] = $img;
        }

        /**
         * Filter Open Graph data array.
         *
         * @param array<string,string> $og      OG property map.
         * @param int                  $post_id Current queried object ID.
         */
        return (array) apply_filters( 'simple_seo_opengraph_data', $og, get_queried_object_id() );
    }

    // ── Twitter Cards ────────────────────────────────────────────────────────

    /**
     * Output Twitter Card tags.
     */
    public function output_twitter_cards(): void {
        $data = $this->build_twitter_data();
        if ( empty( $data ) ) {
            return;
        }

        echo "\n<!-- Simple SEO: Twitter Cards -->\n";

        foreach ( $data as $name => $content ) {
            if ( '' === $content ) {
                continue;
            }
            printf(
                '<meta name="%s" content="%s">' . "\n",
                esc_attr( $name ),
                esc_attr( $content )
            );
        }

        echo "<!-- / Simple SEO: Twitter Cards -->\n\n";
    }

    /**
     * Build the Twitter card data array.
     *
     * @return array<string,string>
     */
    private function build_twitter_data(): array {
        if ( is_admin() || is_feed() ) {
            return [];
        }

        /** @var SimpleSEO_Meta $meta */
        $meta  = simple_seo()->get( 'meta' );
        $title = $meta ? $meta->get_title()       : get_the_title();
        $desc  = $meta ? $meta->get_description() : '';

        $twitter = [
            'twitter:card'        => 'summary_large_image',
            'twitter:title'       => $title,
            'twitter:description' => $desc,
        ];

        $site = (string) SimpleSEO_Options::get( 'twitter_site', '' );
        if ( $site ) {
            $twitter['twitter:site'] = '@' . ltrim( $site, '@' );
        }

        if ( is_singular() ) {
            $img = SimpleSEO_Helpers::get_post_image( get_queried_object_id() );
            if ( $img ) {
                $twitter['twitter:image'] = $img;
            }
        }

        return $twitter;
    }
}
