<?php
/**
 * Meta Module – outputs <title> and <meta name="description"> tags.
 *
 * Supports:
 *  - Automatic title/description generation via token patterns.
 *  - Per-post overrides stored in post meta.
 *  - Developer filters: simple_seo_meta_title, simple_seo_meta_description.
 *
 * @package SimpleSEO\Modules\Meta
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Meta {

    // Post meta keys.
    const META_TITLE       = '_simple_seo_title';
    const META_DESCRIPTION = '_simple_seo_description';
    const META_KEYWORD     = '_simple_seo_keyword';

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        // Replace the default <title> tag.
        add_filter( 'pre_get_document_title', [ $this, 'get_title' ], 20 );

        // Output description meta tag in <head>.
        add_action( 'wp_head', [ $this, 'output_meta_tags' ], 1 );
    }

    // ── Title ────────────────────────────────────────────────────────────────

    /**
     * Build the SEO <title> for the current page.
     *
     * @return string
     */
    public function get_title(): string {
        $title = '';

        if ( is_singular() ) {
            $post_id  = get_queried_object_id();
            $override = get_post_meta( $post_id, self::META_TITLE, true );

            if ( $override ) {
                $title = $override;
            } else {
                $pattern = SimpleSEO_Options::get( 'title_pattern_post' );
                $title   = SimpleSEO_Helpers::parse_tokens( $pattern, [
                    'title'     => get_the_title( $post_id ),
                    'site_name' => get_bloginfo( 'name' ),
                ] );
            }
        } elseif ( is_tax() || is_category() || is_tag() ) {
            $term    = get_queried_object();
            $pattern = SimpleSEO_Options::get( 'title_pattern_term' );
            $title   = SimpleSEO_Helpers::parse_tokens( $pattern, [
                'term'      => $term->name ?? '',
                'site_name' => get_bloginfo( 'name' ),
            ] );
        } elseif ( is_home() || is_front_page() ) {
            $title = get_bloginfo( 'name' ) . ' – ' . get_bloginfo( 'description' );
        } elseif ( is_search() ) {
            /* translators: %s: search query */
            $title = sprintf( __( 'Search: %s – %s', 'simple-seo' ), get_search_query(), get_bloginfo( 'name' ) );
        } elseif ( is_404() ) {
            $title = __( 'Page Not Found', 'simple-seo' ) . ' – ' . get_bloginfo( 'name' );
        }

        if ( '' === $title ) {
            // Fall back to WordPress default.
            return wp_get_document_title();
        }

        /**
         * Filter the final SEO title.
         *
         * @param string $title    Computed title.
         * @param int    $post_id  Post ID (0 for non-singular pages).
         */
        return (string) apply_filters( 'simple_seo_meta_title', $title, get_queried_object_id() );
    }

    // ── Description ──────────────────────────────────────────────────────────

    /**
     * Build the meta description for the current page.
     *
     * @return string
     */
    public function get_description(): string {
        $desc    = '';
        $length  = (int) SimpleSEO_Options::get( 'meta_desc_length', 160 );

        if ( is_singular() ) {
            $post_id  = get_queried_object_id();
            $override = get_post_meta( $post_id, self::META_DESCRIPTION, true );

            if ( $override ) {
                $desc = $override;
            } else {
                $post = get_post( $post_id );
                // Use excerpt first, then fall back to content.
                $source = $post->post_excerpt ?: $post->post_content;
                $desc   = SimpleSEO_Helpers::truncate( $source, $length );
            }
        } elseif ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            $desc = SimpleSEO_Helpers::truncate( $term->description ?? '', $length );
        } elseif ( is_home() || is_front_page() ) {
            $desc = SimpleSEO_Helpers::truncate( get_bloginfo( 'description' ), $length );
        }

        /**
         * Filter the final meta description.
         *
         * @param string $desc    Computed description.
         * @param int    $post_id Post ID (0 for non-singular pages).
         */
        return (string) apply_filters( 'simple_seo_meta_description', $desc, get_queried_object_id() );
    }

    // ── Output ───────────────────────────────────────────────────────────────

    /**
     * Echo the <meta name="description"> tag (and canonical).
     */
    public function output_meta_tags(): void {
        // Description.
        $desc = $this->get_description();
        if ( $desc ) {
            printf(
                '<meta name="description" content="%s">' . "\n",
                esc_attr( $desc )
            );
        }

        // Canonical URL.
        $canonical = $this->get_canonical();
        if ( $canonical ) {
            printf(
                '<link rel="canonical" href="%s">' . "\n",
                esc_url( $canonical )
            );
        }
    }

    // ── Canonical ────────────────────────────────────────────────────────────

    /**
     * Return the canonical URL for the current page.
     *
     * @return string
     */
    private function get_canonical(): string {
        if ( is_singular() ) {
            return (string) get_permalink( get_queried_object_id() );
        }
        return '';
    }
}
