# Simple SEO

**Simple SEO** is a lightweight, production-ready WordPress plugin designed for performance-conscious site owners. It provides all the essential SEO tools you need without the bloat of traditional "all-in-one" plugins.

## 🚀 Key Features

- **Blazing Fast**: Designed with zero bloat and optimized database queries to ensure your site stays fast.
- **Dynamic Meta Management**: Control your `<title>` and `<meta name="description">` tags with flexible token patterns or manual per-post overrides.
- **Smart Sitemaps**: Automatically generates XML sitemaps for posts, pages, categories, and tags, with built-in robots.txt control.
- **Social Graph Optimization**: Includes OpenGraph and Twitter Cards support to ensure your content looks great on Facebook, LinkedIn, Twitter, and more.
- **Structured Data (Schema)**: Enhanced search appearance with automatic Schema.org JSON-LD output for organizations and articles.
- **Redirect Manager**: Easily manage 301 and 302 redirects from within your WordPress dashboard.
- **404 Monitoring**: Keep track of broken links and redirect them to improve user experience and SEO.
- **Image SEO**: Automatically add missing ALT text to your images based on their titles.
- **Internal Linking**: Intelligent suggestions and auto-linking to help you build a stronger internal link structure.

## 🛠 Modules

### 📝 Meta & Title Management
- **Automatic Titles**: Use patterns like `{title} - {site_name}` to maintain a consistent brand identity.
- **Descriptions**: Automatically generates descriptions from excerpts or content, or provide manual overrides.
- **Tokens Supported**: `{title}`, `{site_name}`, `{term}`, `{site_desc}`.

### 🗺 XML Sitemaps
- High-performance sitemap generation.
- Supports posts, pages, and all public taxonomies.
- Customisable via settings.

### 🔗 Redirects & 404s
- Create custom 301/302 redirects.
- Automated hit tracking for active redirects.
- Comprehensive 404 log to find and fix broken links.

### 🖼 Social Media (OpenGraph & Twitter)
- **OpenGraph Support**: Optimized sharing for Facebook and LinkedIn.
- **Twitter Cards**: Enhanced display when your content is shared on Twitter.
- **Smart Image Selection**: Automatic selection (Featured → First in Content → Default).

### 🔍 Schema (Structured Data)
- **JSON-LD Implementation**: Clean and efficient Schema output.
- **Organization & Website**: Proper site-wide structured data.
- **Articles & Pages**: Enhanced search visibility for your content.

### 📷 Image SEO
- **Auto Alt Text**: Automatically generates missing ALT attributes from image file names or post titles.
- **Performance Optimized**: No heavy processing on the frontend.

## 📦 Installation

1. Upload the `simple-seo` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **SEO** in your sidebar to configure your settings.

## 👨‍💻 For Developers

Simple SEO is built to be extendable. You can use the following filters to customize behavior:

### Customizing Titles & Descriptions
```php
// Filter the SEO title
add_filter( 'simple_seo_meta_title', function( $title, $post_id ) {
    return "Custom Prefix: " . $title;
}, 10, 2 );

// Filter the meta description
add_filter( 'simple_seo_meta_description', function( $desc, $post_id ) {
    return $desc . " | New Slogan";
}, 10, 2 );
```

### Technical Requirements
- **PHP**: 8.0 or higher.
- **WordPress**: 6.0 or higher.

## 📄 License
GPL v2 or later.
