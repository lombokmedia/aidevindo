<?php
/**
 * Static utility helpers used across the plugin.
 *
 * @package SimpleSEO\Core
 */

defined( 'ABSPATH' ) || exit;

final class SimpleSEO_Helpers {

    // No instantiation needed – all static.
    private function __construct() {}

    // ── String helpers ───────────────────────────────────────────────────────

    /**
     * Truncate a string to a given length, appending ellipsis if needed.
     *
     * @param string $text   Raw text.
     * @param int    $length Maximum characters.
     * @return string
     */
    public static function truncate( string $text, int $length = 160 ): string {
        $text = wp_strip_all_tags( $text );
        $text = preg_replace( '/\s+/', ' ', $text );
        $text = trim( $text );

        if ( mb_strlen( $text ) <= $length ) {
            return $text;
        }

        return mb_substr( $text, 0, $length - 1 ) . '…';
    }

    /**
     * Replace simple template tokens like {title}, {site_name} etc.
     *
     * @param string               $pattern Pattern string.
     * @param array<string,string> $tokens  Token => value map.
     * @return string
     */
    public static function parse_tokens( string $pattern, array $tokens ): string {
        foreach ( $tokens as $token => $value ) {
            $pattern = str_replace( '{' . $token . '}', $value, $pattern );
        }
        return $pattern;
    }

    // ── Post helpers ─────────────────────────────────────────────────────────

    /**
     * Get the first image URL from post content.
     *
     * @param int $post_id Post ID.
     * @return string Empty string if not found.
     */
    public static function get_first_content_image( int $post_id ): string {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return '';
        }

        preg_match( '/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $post->post_content, $matches );

        return $matches[1] ?? '';
    }

    /**
     * Get the best available image URL for a post (featured → content → default).
     *
     * @param int $post_id Post ID.
     * @return string
     */
    public static function get_post_image( int $post_id ): string {
        // Featured image.
        if ( has_post_thumbnail( $post_id ) ) {
            $src = get_the_post_thumbnail_url( $post_id, 'large' );
            if ( $src ) {
                return $src;
            }
        }

        // First image from content.
        $content_img = self::get_first_content_image( $post_id );
        if ( $content_img ) {
            return $content_img;
        }

        // Global default from options.
        return (string) SimpleSEO_Options::get( 'og_default_image', '' );
    }

    // ── URL helpers ──────────────────────────────────────────────────────────

    /**
     * Normalise a URL path (ensure leading slash, trim trailing slash).
     *
     * @param string $path URL path.
     * @return string
     */
    public static function normalise_path( string $path ): string {
        $path = trim( $path );
        if ( '' === $path ) {
            return '/';
        }
        $path = '/' . ltrim( $path, '/' );
        return rtrim( $path, '/' );
    }

    // ── Security helpers ─────────────────────────────────────────────────────

    /**
     * Verify a nonce and die on failure.
     *
     * @param string $action Nonce action.
     * @param string $field  $_POST field name.
     */
    public static function verify_nonce( string $action, string $field = '_simple_seo_nonce' ): void {
        if ( ! isset( $_POST[ $field ] )
             || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $field ] ) ), $action )
        ) {
            wp_die( esc_html__( 'Security check failed.', 'simple-seo' ), 403 );
        }
    }

    /**
     * Check current user capability and die on failure.
     *
     * @param string $cap Required capability.
     */
    public static function require_capability( string $cap = 'manage_options' ): void {
        if ( ! current_user_can( $cap ) ) {
            wp_die( esc_html__( 'You do not have permission to do this.', 'simple-seo' ), 403 );
        }
    }
}
