<?php
/**
 * Core Loader / Service Container.
 *
 * Bootstraps every module and wires up WordPress hooks.
 *
 * @package SimpleSEO\Core
 */

defined( 'ABSPATH' ) || exit;

final class SimpleSEO_Loader {

    /** @var self|null */
    private static ?self $instance = null;

    /** @var array<string, object> Registered service instances. */
    private array $services = [];

    // ── Singleton ────────────────────────────────────────────────────────────

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->init();
        }
        return self::$instance;
    }

    private function __construct() {}

    // ── Initialisation ───────────────────────────────────────────────────────

    private function init(): void {
        $this->load_textdomain();
        $this->register_services();
        $this->boot_services();
    }

    private function load_textdomain(): void {
        load_plugin_textdomain(
            'simple-seo',
            false,
            dirname( plugin_basename( SIMPLE_SEO_FILE ) ) . '/languages'
        );
    }

    /**
     * Instantiate every module and store in the service map.
     */
    private function register_services(): void {
        $this->services = [
            'meta'           => new SimpleSEO_Meta(),
            'opengraph'      => new SimpleSEO_OpenGraph(),
            'sitemap'        => new SimpleSEO_Sitemap(),
            'robots'         => new SimpleSEO_Robots(),
            'schema'         => new SimpleSEO_Schema(),
            'redirect'       => new SimpleSEO_Redirect(),
            'internal_links' => new SimpleSEO_Internal_Links(),
            'image_seo'      => new SimpleSEO_Image_SEO(),
        ];

        if ( is_admin() ) {
            $this->services['admin']            = new SimpleSEO_Admin();
            $this->services['meta_box']         = new SimpleSEO_Meta_Box();
            $this->services['meta_analysis']    = new SimpleSEO_Meta_Analysis();
            $this->services['admin_settings']   = new SimpleSEO_Admin_Settings();
            $this->services['admin_sitemap']    = new SimpleSEO_Admin_Sitemap();
            $this->services['admin_redirects']  = new SimpleSEO_Admin_Redirects();
        }
    }

    /**
     * Call register_hooks() on every service that exposes it.
     */
    private function boot_services(): void {
        foreach ( $this->services as $service ) {
            if ( method_exists( $service, 'register_hooks' ) ) {
                $service->register_hooks();
            }
        }
    }

    // ── Service Accessor ─────────────────────────────────────────────────────

    /**
     * Retrieve a registered service by key.
     *
     * @param string $key Service identifier.
     * @return object|null
     */
    public function get( string $key ): ?object {
        return $this->services[ $key ] ?? null;
    }
}
