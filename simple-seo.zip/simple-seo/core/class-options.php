<?php
/**
 * Thin wrapper around WordPress options for Simple SEO.
 *
 * All settings live in a single serialised option array: `simple_seo_options`.
 *
 * @package SimpleSEO\Core
 */

defined( 'ABSPATH' ) || exit;

final class SimpleSEO_Options {

    /** WordPress option key. */
    const OPTION_KEY = 'simple_seo_options';

    /** @var array<string,mixed>|null In-memory cache. */
    private static ?array $cache = null;

    private function __construct() {}

    // ── Defaults ─────────────────────────────────────────────────────────────

    /**
     * Default option values.
     *
     * @return array<string,mixed>
     */
    public static function defaults(): array {
        return [
            // Meta
            'title_pattern_post'    => '{title} - {site_name}',
            'title_pattern_term'    => '{term} - {site_name}',
            'meta_desc_length'      => 160,

            // Open Graph / Twitter
            'og_enabled'            => true,
            'twitter_cards_enabled' => true,
            'og_default_image'      => '',
            'twitter_site'          => '',

            // Sitemap
            'sitemap_post_types'    => [ 'post', 'page' ],
            'sitemap_taxonomies'    => [ 'category', 'post_tag' ],
            'sitemap_cache_ttl'     => 3600,

            // Schema
            'schema_enabled'        => true,
            'org_name'              => get_bloginfo( 'name' ),
            'org_url'               => home_url(),
            'org_logo'              => '',

            // Redirects
            'redirect_log_404'      => true,

            // Internal links
            'auto_link_enabled'     => false,
            'auto_link_per_post'    => 3,

            // Image SEO
            'image_auto_alt'        => true,
        ];
    }

    // ── Read ─────────────────────────────────────────────────────────────────

    /**
     * Get a single option value.
     *
     * @param string $key     Option key.
     * @param mixed  $default Fallback value (uses built-in default if null).
     * @return mixed
     */
    public static function get( string $key, mixed $default = null ): mixed {
        $options  = self::all();
        $defaults = self::defaults();

        if ( array_key_exists( $key, $options ) ) {
            return $options[ $key ];
        }

        if ( null !== $default ) {
            return $default;
        }

        return $defaults[ $key ] ?? null;
    }

    /**
     * Return all options merged with defaults.
     *
     * @return array<string,mixed>
     */
    public static function all(): array {
        if ( null === self::$cache ) {
            $saved        = get_option( self::OPTION_KEY, [] );
            self::$cache  = array_merge( self::defaults(), is_array( $saved ) ? $saved : [] );
        }
        return self::$cache;
    }

    // ── Write ────────────────────────────────────────────────────────────────

    /**
     * Save a single option value.
     *
     * @param string $key   Option key.
     * @param mixed  $value Option value.
     */
    public static function set( string $key, mixed $value ): void {
        $options         = self::all();
        $options[ $key ] = $value;
        update_option( self::OPTION_KEY, $options, false );
        self::$cache = $options;
    }

    /**
     * Save an array of options at once.
     *
     * @param array<string,mixed> $data Options to merge and save.
     */
    public static function save( array $data ): void {
        $options = array_merge( self::all(), $data );
        update_option( self::OPTION_KEY, $options, false );
        self::$cache = $options;
    }

    /**
     * Flush the in-memory cache (useful after saving).
     */
    public static function flush(): void {
        self::$cache = null;
    }
}
