<?php
/**
 * Handles plugin activation, deactivation, and database setup.
 *
 * @package SimpleSEO\Core
 */

defined( 'ABSPATH' ) || exit;

final class SimpleSEO_Install {

    /** DB table name (without prefix). */
    const TABLE_REDIRECTS = 'simple_seo_redirects';

    /** DB table name (without prefix). */
    const TABLE_404_LOG   = 'simple_seo_404_log';

    // ── Hooks ────────────────────────────────────────────────────────────────

    /**
     * Run on plugin activation.
     */
    public static function activate(): void {
        self::create_tables();
        self::seed_defaults();
        self::flush_rewrites();

        update_option( 'simple_seo_version', SIMPLE_SEO_VERSION, false );
    }

    /**
     * Run on plugin deactivation.
     */
    public static function deactivate(): void {
        // Remove rewrite rules added by sitemap module.
        flush_rewrite_rules();

        // Clear cached sitemap.
        delete_transient( 'simple_seo_sitemap' );
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Create custom database tables using dbDelta.
     */
    private static function create_tables(): void {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $redirects_table = $wpdb->prefix . self::TABLE_REDIRECTS;
        $log_table       = $wpdb->prefix . self::TABLE_404_LOG;

        $sql = "
            CREATE TABLE {$redirects_table} (
                id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                source      VARCHAR(512)        NOT NULL DEFAULT '',
                destination VARCHAR(512)        NOT NULL DEFAULT '',
                code        SMALLINT(4)         NOT NULL DEFAULT 301,
                hits        BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY   source (source(255))
            ) {$charset_collate};

            CREATE TABLE {$log_table} (
                id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                url        VARCHAR(512)        NOT NULL DEFAULT '',
                referrer   VARCHAR(512)        NOT NULL DEFAULT '',
                hits       BIGINT(20) UNSIGNED NOT NULL DEFAULT 1,
                last_seen  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY  url (url(255))
            ) {$charset_collate};
        ";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Persist default options if not already saved.
     */
    private static function seed_defaults(): void {
        if ( false === get_option( SimpleSEO_Options::OPTION_KEY ) ) {
            add_option( SimpleSEO_Options::OPTION_KEY, SimpleSEO_Options::defaults(), '', false );
        }
    }

    /**
     * Flush WordPress rewrite rules so sitemap endpoint works immediately.
     */
    private static function flush_rewrites(): void {
        // We need the sitemap rewrite rule registered first.
        // Add it directly here so flush_rewrite_rules picks it up.
        add_rewrite_rule( '^sitemap\.xml$', 'index.php?simple_seo_sitemap=1', 'top' );
        flush_rewrite_rules();
    }
}
