<?php
/**
 * Redirects Admin Page.
 *
 * Full CRUD interface for 301 redirects.
 * Also displays the 404 log table.
 *
 * @package SimpleSEO\Admin
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Admin_Redirects {

    public function register_hooks(): void {
        add_action( 'admin_post_simple_seo_save_redirect',   [ $this, 'handle_save' ] );
        add_action( 'admin_post_simple_seo_delete_redirect', [ $this, 'handle_delete' ] );
        add_action( 'admin_post_simple_seo_bulk_redirects',  [ $this, 'handle_bulk_delete' ] );
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render_page(): void {
        SimpleSEO_Helpers::require_capability();

        /** @var SimpleSEO_Redirect $redirect */
        $redirect = simple_seo()->get( 'redirect' );

        /** @var SimpleSEO_Redirect_Table $table */
        $table = new SimpleSEO_Redirect_Table();
        $table->prepare_items();

        $notice = isset( $_GET['sseo_notice'] ) ? sanitize_key( $_GET['sseo_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

        // Edit mode?
        $edit_id  = isset( $_GET['redirect_id'] ) ? absint( $_GET['redirect_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
        $edit_row = null;

        if ( $edit_id ) {
            global $wpdb;
            $tbl      = $wpdb->prefix . SimpleSEO_Install::TABLE_REDIRECTS;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $edit_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id = %d", $edit_id ), ARRAY_A );
        }
        ?>
        <div class="wrap sseo-wrap">
            <h1><?php esc_html_e( 'Simple SEO – Redirects', 'simple-seo' ); ?></h1>

            <?php if ( $notice ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Redirect saved successfully.', 'simple-seo' ); ?></p>
                </div>
            <?php endif; ?>

            <?php /* ── Add / Edit form ─────────────────────────────────── */ ?>
            <h2><?php echo $edit_row ? esc_html__( 'Edit Redirect', 'simple-seo' ) : esc_html__( 'Add Redirect', 'simple-seo' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="simple_seo_save_redirect" />
                <?php if ( $edit_row ) : ?>
                    <input type="hidden" name="redirect_id" value="<?php echo esc_attr( $edit_row['id'] ); ?>" />
                <?php endif; ?>
                <?php wp_nonce_field( 'simple_seo_save_redirect' ); ?>

                <table class="form-table">
                    <tr>
                        <th><label for="sseo-source"><?php esc_html_e( 'Source Path', 'simple-seo' ); ?></label></th>
                        <td>
                            <input type="text" id="sseo-source" name="redirect_source"
                                value="<?php echo esc_attr( $edit_row['source'] ?? '' ); ?>"
                                placeholder="/old-page/" class="regular-text" required />
                            <p class="description"><?php esc_html_e( 'Relative path, e.g. /old-page/', 'simple-seo' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="sseo-dest"><?php esc_html_e( 'Destination URL', 'simple-seo' ); ?></label></th>
                        <td>
                            <input type="text" id="sseo-dest" name="redirect_destination"
                                value="<?php echo esc_attr( $edit_row['destination'] ?? '' ); ?>"
                                placeholder="https://example.com/new-page/" class="regular-text" required />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="sseo-code"><?php esc_html_e( 'HTTP Code', 'simple-seo' ); ?></label></th>
                        <td>
                            <select id="sseo-code" name="redirect_code">
                                <option value="301" <?php selected( $edit_row['code'] ?? '301', '301' ); ?>>301 – Permanent</option>
                                <option value="302" <?php selected( $edit_row['code'] ?? '', '302' ); ?>>302 – Temporary</option>
                            </select>
                        </td>
                    </tr>
                </table>

                <?php submit_button( $edit_row ? __( 'Update Redirect', 'simple-seo' ) : __( 'Add Redirect', 'simple-seo' ) ); ?>
            </form>

            <hr>

            <?php /* ── Redirect list ─────────────────────────────────────── */ ?>
            <h2><?php esc_html_e( 'All Redirects', 'simple-seo' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="simple_seo_bulk_redirects" />
                <?php wp_nonce_field( 'simple_seo_bulk_redirects' ); ?>
                <?php $table->display(); ?>
            </form>

            <hr>

            <?php /* ── 404 Log ──────────────────────────────────────────── */ ?>
            <?php if ( SimpleSEO_Options::get( 'redirect_log_404', true ) ) : ?>
                <h2><?php esc_html_e( '404 Log', 'simple-seo' ); ?></h2>
                <p class="description">
                    <?php esc_html_e( 'Most frequently hit 404 URLs. Click "Add Redirect" to fix them.', 'simple-seo' ); ?>
                </p>
                <?php
                $logs = $redirect->get_404_log( 30 );
                if ( $logs ) :
                ?>
                <table class="wp-list-table widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'URL', 'simple-seo' ); ?></th>
                            <th><?php esc_html_e( 'Referrer', 'simple-seo' ); ?></th>
                            <th><?php esc_html_e( 'Hits', 'simple-seo' ); ?></th>
                            <th><?php esc_html_e( 'Last Seen', 'simple-seo' ); ?></th>
                            <th><?php esc_html_e( 'Action', 'simple-seo' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $logs as $log ) : ?>
                        <tr>
                            <td><code><?php echo esc_html( $log['url'] ); ?></code></td>
                            <td><?php echo esc_html( $log['referrer'] ?: '—' ); ?></td>
                            <td><?php echo esc_html( $log['hits'] ); ?></td>
                            <td><?php echo esc_html( $log['last_seen'] ); ?></td>
                            <td>
                                <a href="<?php echo esc_url( add_query_arg( [
                                    'page'            => 'simple-seo-redirects',
                                    'redirect_source' => rawurlencode( $log['url'] ),
                                ], admin_url( 'admin.php' ) ) ); ?>" class="button button-small">
                                    <?php esc_html_e( 'Add Redirect', 'simple-seo' ); ?>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else : ?>
                    <p><?php esc_html_e( 'No 404s logged yet.', 'simple-seo' ); ?></p>
                <?php endif; ?>
            <?php endif; ?>

        </div><!-- .wrap -->
        <?php
    }

    // ── Handlers ─────────────────────────────────────────────────────────────

    public function handle_save(): void {
        SimpleSEO_Helpers::require_capability();
        check_admin_referer( 'simple_seo_save_redirect' );

        $source = SimpleSEO_Helpers::normalise_path(
            sanitize_text_field( wp_unslash( $_POST['redirect_source'] ?? '' ) )
        );
        $dest   = esc_url_raw( wp_unslash( $_POST['redirect_destination'] ?? '' ) );
        $code   = in_array( (int) ( $_POST['redirect_code'] ?? 301 ), [ 301, 302 ], true )
                  ? (int) $_POST['redirect_code']
                  : 301;

        if ( $source && $dest ) {
            /** @var SimpleSEO_Redirect $redirect */
            $redirect = simple_seo()->get( 'redirect' );
            $redirect->upsert( $source, $dest, $code );
        }

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'simple-seo-redirects', 'sseo_notice' => 'saved' ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    public function handle_delete(): void {
        SimpleSEO_Helpers::require_capability();

        $id = absint( $_GET['redirect_id'] ?? 0 );
        check_admin_referer( 'simple_seo_delete_redirect_' . $id );

        /** @var SimpleSEO_Redirect $redirect */
        $redirect = simple_seo()->get( 'redirect' );
        $redirect->delete( $id );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'simple-seo-redirects' ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    public function handle_bulk_delete(): void {
        SimpleSEO_Helpers::require_capability();
        check_admin_referer( 'simple_seo_bulk_redirects' );

        $action = sanitize_key( $_POST['action'] ?? $_POST['action2'] ?? '' );

        if ( 'delete' === $action && ! empty( $_POST['redirect_ids'] ) ) {
            /** @var SimpleSEO_Redirect $redirect */
            $redirect = simple_seo()->get( 'redirect' );
            $ids      = array_map( 'absint', (array) $_POST['redirect_ids'] );
            foreach ( $ids as $id ) {
                $redirect->delete( $id );
            }
        }

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'simple-seo-redirects' ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }
}
