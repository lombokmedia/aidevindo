/**
 * Simple SEO – Meta Box Script
 *
 * Vanilla JS only (no jQuery dependency).
 * Handles:
 *  - Character counters for title & description fields.
 *  - Live Google SERP preview update.
 */

( function () {
    'use strict';

    // ── DOM references ────────────────────────────────────────────────────────

    const titleInput    = document.getElementById( 'sseo-title' );
    const descInput     = document.getElementById( 'sseo-description' );
    const titleCounter  = document.getElementById( 'sseo-title-counter' );
    const descCounter   = document.getElementById( 'sseo-desc-counter' );
    const previewTitle  = document.getElementById( 'sseo-preview-title' );
    const previewDesc   = document.getElementById( 'sseo-preview-desc' );

    if ( ! titleInput || ! descInput ) {
        return; // Not on a post edit page.
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Update a character counter element.
     *
     * @param {HTMLInputElement|HTMLTextAreaElement} input   Field.
     * @param {HTMLElement}                          counter Counter element.
     * @param {number}                               max     Max recommended length.
     */
    function updateCounter( input, counter, max ) {
        const len = input.value.length;
        counter.textContent = len + ' / ' + max;
        counter.classList.toggle( 'sseo-over', len > max );
    }

    /**
     * Update the Google SERP preview.
     */
    function updatePreview() {
        const title = titleInput.value || titleInput.getAttribute( 'data-fallback' ) || '';
        const desc  = descInput.value  || descInput.getAttribute( 'data-fallback' )  || '';

        if ( previewTitle ) {
            previewTitle.textContent = title;
        }
        if ( previewDesc ) {
            previewDesc.textContent = desc;
        }
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    // Run once on load.
    updateCounter( titleInput, titleCounter, 60 );
    updateCounter( descInput,  descCounter,  160 );
    updatePreview();

    // ── Events ────────────────────────────────────────────────────────────────

    titleInput.addEventListener( 'input', function () {
        updateCounter( titleInput, titleCounter, 60 );
        updatePreview();
    } );

    descInput.addEventListener( 'input', function () {
        updateCounter( descInput, descCounter, 160 );
        updatePreview();
    } );

} )();
