<?php
/**
 * Settings Admin Page.
 *
 * A single options page rendered with the WordPress Settings API.
 *
 * @package SimpleSEO\Admin
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Admin_Settings {

    const OPTION_GROUP = 'simple_seo_settings_group';
    const PAGE_SLUG    = 'simple-seo-settings';

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    // ── Settings API ─────────────────────────────────────────────────────────

    public function register_settings(): void {
        register_setting(
            self::OPTION_GROUP,
            SimpleSEO_Options::OPTION_KEY,
            [ $this, 'sanitize_settings' ]
        );

        // ── Meta section ────────────────────────────────────────────────────
        add_settings_section( 'sseo_meta', __( 'Meta Tags', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'title_pattern_post', __( 'Post Title Pattern', 'simple-seo' ),
            [ $this, 'field_text' ], self::PAGE_SLUG, 'sseo_meta',
            [ 'key' => 'title_pattern_post', 'desc' => __( 'Available tokens: {title}, {site_name}', 'simple-seo' ) ] );

        add_settings_field( 'title_pattern_term', __( 'Term Title Pattern', 'simple-seo' ),
            [ $this, 'field_text' ], self::PAGE_SLUG, 'sseo_meta',
            [ 'key' => 'title_pattern_term', 'desc' => __( 'Available tokens: {term}, {site_name}', 'simple-seo' ) ] );

        // ── Open Graph section ───────────────────────────────────────────────
        add_settings_section( 'sseo_og', __( 'Open Graph & Twitter', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'og_enabled', __( 'Enable Open Graph', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_og', [ 'key' => 'og_enabled' ] );

        add_settings_field( 'twitter_cards_enabled', __( 'Enable Twitter Cards', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_og', [ 'key' => 'twitter_cards_enabled' ] );

        add_settings_field( 'og_default_image', __( 'Default OG Image URL', 'simple-seo' ),
            [ $this, 'field_url' ], self::PAGE_SLUG, 'sseo_og', [ 'key' => 'og_default_image' ] );

        add_settings_field( 'twitter_site', __( 'Twitter @username', 'simple-seo' ),
            [ $this, 'field_text' ], self::PAGE_SLUG, 'sseo_og',
            [ 'key' => 'twitter_site', 'desc' => __( 'Without the @ prefix', 'simple-seo' ) ] );

        // ── Schema section ───────────────────────────────────────────────────
        add_settings_section( 'sseo_schema', __( 'Schema', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'schema_enabled', __( 'Enable JSON-LD Schema', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_schema', [ 'key' => 'schema_enabled' ] );

        add_settings_field( 'org_name', __( 'Organisation Name', 'simple-seo' ),
            [ $this, 'field_text' ], self::PAGE_SLUG, 'sseo_schema', [ 'key' => 'org_name' ] );

        add_settings_field( 'org_logo', __( 'Organisation Logo URL', 'simple-seo' ),
            [ $this, 'field_url' ], self::PAGE_SLUG, 'sseo_schema', [ 'key' => 'org_logo' ] );

        // ── Sitemap section ──────────────────────────────────────────────────
        add_settings_section( 'sseo_sitemap', __( 'Sitemap', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'sitemap_cache_ttl', __( 'Cache TTL (seconds)', 'simple-seo' ),
            [ $this, 'field_number' ], self::PAGE_SLUG, 'sseo_sitemap', [ 'key' => 'sitemap_cache_ttl' ] );

        // ── Internal Links section ───────────────────────────────────────────
        add_settings_section( 'sseo_ilinks', __( 'Internal Linking', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'auto_link_enabled', __( 'Auto-insert Internal Links', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_ilinks', [ 'key' => 'auto_link_enabled' ] );

        add_settings_field( 'auto_link_per_post', __( 'Max Links per Post', 'simple-seo' ),
            [ $this, 'field_number' ], self::PAGE_SLUG, 'sseo_ilinks', [ 'key' => 'auto_link_per_post' ] );

        // ── Image SEO section ────────────────────────────────────────────────
        add_settings_section( 'sseo_images', __( 'Image SEO', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'image_auto_alt', __( 'Auto-add Missing ALT Text', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_images', [ 'key' => 'image_auto_alt' ] );

        // ── Redirects section ────────────────────────────────────────────────
        add_settings_section( 'sseo_redirects', __( 'Redirects', 'simple-seo' ), '__return_false', self::PAGE_SLUG );

        add_settings_field( 'redirect_log_404', __( 'Log 404 URLs', 'simple-seo' ),
            [ $this, 'field_checkbox' ], self::PAGE_SLUG, 'sseo_redirects', [ 'key' => 'redirect_log_404' ] );
    }

    // ── Sanitise ─────────────────────────────────────────────────────────────

    /**
     * Sanitise the settings array before saving.
     *
     * @param mixed $input Raw input (should be array).
     * @return array<string,mixed>
     */
    public function sanitize_settings( mixed $input ): array {
        if ( ! is_array( $input ) ) {
            return SimpleSEO_Options::defaults();
        }

        $clean   = SimpleSEO_Options::all();
        $strings = [ 'title_pattern_post', 'title_pattern_term', 'twitter_site', 'org_name' ];
        $urls    = [ 'og_default_image', 'org_logo', 'org_url' ];
        $bools   = [ 'og_enabled', 'twitter_cards_enabled', 'schema_enabled', 'auto_link_enabled', 'image_auto_alt', 'redirect_log_404' ];
        $ints    = [ 'sitemap_cache_ttl', 'auto_link_per_post', 'meta_desc_length' ];

        foreach ( $strings as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $clean[ $key ] = sanitize_text_field( $input[ $key ] );
            }
        }
        foreach ( $urls as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $clean[ $key ] = esc_url_raw( $input[ $key ] );
            }
        }
        foreach ( $bools as $key ) {
            $clean[ $key ] = ! empty( $input[ $key ] );
        }
        foreach ( $ints as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $clean[ $key ] = absint( $input[ $key ] );
            }
        }

        SimpleSEO_Options::flush();
        return $clean;
    }

    // ── Page Render ───────────────────────────────────────────────────────────

    public function render_page(): void {
        SimpleSEO_Helpers::require_capability();
        ?>
        <div class="wrap sseo-wrap">
            <h1><?php esc_html_e( 'Simple SEO – Settings', 'simple-seo' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( self::OPTION_GROUP );
                do_settings_sections( self::PAGE_SLUG );
                submit_button( __( 'Save Settings', 'simple-seo' ) );
                ?>
            </form>
        </div>
        <?php
    }

    // ── Field helpers ─────────────────────────────────────────────────────────

    /** @param array<string,string> $args */
    public function field_text( array $args ): void {
        $key  = $args['key'];
        $desc = $args['desc'] ?? '';
        $val  = SimpleSEO_Options::get( $key, '' );
        printf(
            '<input type="text" name="%1$s[%2$s]" value="%3$s" class="regular-text" /><p class="description">%4$s</p>',
            esc_attr( SimpleSEO_Options::OPTION_KEY ),
            esc_attr( $key ),
            esc_attr( (string) $val ),
            esc_html( $desc )
        );
    }

    /** @param array<string,string> $args */
    public function field_url( array $args ): void {
        $key = $args['key'];
        $val = SimpleSEO_Options::get( $key, '' );
        printf(
            '<input type="url" name="%1$s[%2$s]" value="%3$s" class="regular-text" />',
            esc_attr( SimpleSEO_Options::OPTION_KEY ),
            esc_attr( $key ),
            esc_attr( (string) $val )
        );
    }

    /** @param array<string,string> $args */
    public function field_checkbox( array $args ): void {
        $key = $args['key'];
        $val = SimpleSEO_Options::get( $key, false );
        printf(
            '<input type="checkbox" name="%1$s[%2$s]" value="1" %3$s />',
            esc_attr( SimpleSEO_Options::OPTION_KEY ),
            esc_attr( $key ),
            checked( $val, true, false )
        );
    }

    /** @param array<string,string> $args */
    public function field_number( array $args ): void {
        $key = $args['key'];
        $val = SimpleSEO_Options::get( $key, 0 );
        printf(
            '<input type="number" name="%1$s[%2$s]" value="%3$s" min="0" class="small-text" />',
            esc_attr( SimpleSEO_Options::OPTION_KEY ),
            esc_attr( $key ),
            esc_attr( (string) $val )
        );
    }
}
