<?php
/**
 * Admin Menu Registration.
 *
 * Registers the top-level "Simple SEO" admin menu and its sub-pages.
 *
 * @package SimpleSEO\Admin
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Admin {

    // ── Hooks ────────────────────────────────────────────────────────────────

    public function register_hooks(): void {
        add_action( 'admin_menu',            [ $this, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    // ── Menu ─────────────────────────────────────────────────────────────────

    public function register_menus(): void {
        // Top-level page → Dashboard.
        add_menu_page(
            __( 'Simple SEO', 'simple-seo' ),
            __( 'Simple SEO', 'simple-seo' ),
            'manage_options',
            'simple-seo',
            [ $this, 'render_dashboard' ],
            'dashicons-search',
            80
        );

        // Sub-pages.
        add_submenu_page(
            'simple-seo',
            __( 'Dashboard', 'simple-seo' ),
            __( 'Dashboard', 'simple-seo' ),
            'manage_options',
            'simple-seo',
            [ $this, 'render_dashboard' ]
        );

        add_submenu_page(
            'simple-seo',
            __( 'Settings – Simple SEO', 'simple-seo' ),
            __( 'Settings', 'simple-seo' ),
            'manage_options',
            'simple-seo-settings',
            [ simple_seo()->get( 'admin_settings' ), 'render_page' ]
        );

        add_submenu_page(
            'simple-seo',
            __( 'Sitemap – Simple SEO', 'simple-seo' ),
            __( 'Sitemap', 'simple-seo' ),
            'manage_options',
            'simple-seo-sitemap',
            [ simple_seo()->get( 'admin_sitemap' ), 'render_page' ]
        );

        add_submenu_page(
            'simple-seo',
            __( 'Redirects – Simple SEO', 'simple-seo' ),
            __( 'Redirects', 'simple-seo' ),
            'manage_options',
            'simple-seo-redirects',
            [ simple_seo()->get( 'admin_redirects' ), 'render_page' ]
        );
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────

    public function render_dashboard(): void {
        SimpleSEO_Helpers::require_capability();

        // Quick stats.
        $post_count     = (int) wp_count_posts()->publish;
        $page_count     = (int) wp_count_posts( 'page' )->publish;
        $redirect_count = simple_seo()->get( 'redirect' )?->count() ?? 0;

        // Posts missing focus keyword.
        $no_keyword = get_posts( [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery
                'relation' => 'OR',
                [
                    'key'     => SimpleSEO_Meta::META_KEYWORD,
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key'     => SimpleSEO_Meta::META_KEYWORD,
                    'value'   => '',
                    'compare' => '=',
                ],
            ],
        ] );

        ?>
        <div class="wrap sseo-wrap">
            <h1><?php esc_html_e( 'Simple SEO — Dashboard', 'simple-seo' ); ?></h1>

            <div class="sseo-stats-grid">
                <div class="sseo-stat-card">
                    <span class="sseo-stat-num"><?php echo esc_html( $post_count ); ?></span>
                    <span class="sseo-stat-label"><?php esc_html_e( 'Published Posts', 'simple-seo' ); ?></span>
                </div>
                <div class="sseo-stat-card">
                    <span class="sseo-stat-num"><?php echo esc_html( $page_count ); ?></span>
                    <span class="sseo-stat-label"><?php esc_html_e( 'Published Pages', 'simple-seo' ); ?></span>
                </div>
                <div class="sseo-stat-card">
                    <span class="sseo-stat-num"><?php echo esc_html( $redirect_count ); ?></span>
                    <span class="sseo-stat-label"><?php esc_html_e( 'Active Redirects', 'simple-seo' ); ?></span>
                </div>
                <div class="sseo-stat-card <?php echo count( $no_keyword ) > 0 ? 'sseo-stat-warn' : ''; ?>">
                    <span class="sseo-stat-num"><?php echo esc_html( count( $no_keyword ) ); ?></span>
                    <span class="sseo-stat-label"><?php esc_html_e( 'Posts without Keyword', 'simple-seo' ); ?></span>
                </div>
            </div>

            <h2><?php esc_html_e( 'Quick Links', 'simple-seo' ); ?></h2>
            <ul>
                <li><a href="<?php echo esc_url( admin_url( 'admin.php?page=simple-seo-settings' ) ); ?>">
                    <?php esc_html_e( 'Plugin Settings', 'simple-seo' ); ?>
                </a></li>
                <li><a href="<?php echo esc_url( home_url( '/sitemap.xml' ) ); ?>" target="_blank">
                    <?php esc_html_e( 'View Sitemap', 'simple-seo' ); ?>
                </a></li>
                <li><a href="<?php echo esc_url( admin_url( 'admin.php?page=simple-seo-redirects' ) ); ?>">
                    <?php esc_html_e( 'Manage Redirects', 'simple-seo' ); ?>
                </a></li>
            </ul>

            <p class="description">
                Simple SEO <?php echo esc_html( SIMPLE_SEO_VERSION ); ?>
                &nbsp;|&nbsp;
                <?php esc_html_e( 'Zero config, zero bloat.', 'simple-seo' ); ?>
            </p>
        </div>
        <?php
    }

    // ── Assets ───────────────────────────────────────────────────────────────

    public function enqueue_admin_assets( string $hook_suffix ): void {
        // Load global admin CSS only on our plugin pages.
        if ( ! str_contains( $hook_suffix, 'simple-seo' ) ) {
            return;
        }

        wp_enqueue_style(
            'simple-seo-admin',
            SIMPLE_SEO_URL . 'admin/css/admin.css',
            [],
            SIMPLE_SEO_VERSION
        );
    }
}
