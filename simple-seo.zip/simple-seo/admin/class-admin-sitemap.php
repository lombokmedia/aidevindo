<?php
/**
 * Sitemap Admin Page.
 *
 * Shows sitemap status, cache info, and a manual flush button.
 * Also handles the bulk image ALT fixer action.
 *
 * @package SimpleSEO\Admin
 */

defined( 'ABSPATH' ) || exit;

class SimpleSEO_Admin_Sitemap {

    public function register_hooks(): void {
        add_action( 'admin_post_simple_seo_flush_sitemap',  [ $this, 'handle_flush_sitemap' ] );
        add_action( 'admin_post_simple_seo_bulk_fix_alt',   [ $this, 'handle_bulk_fix_alt' ] );
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render_page(): void {
        SimpleSEO_Helpers::require_capability();

        $sitemap_url    = home_url( '/sitemap.xml' );
        $cache_exists   = false !== get_transient( SimpleSEO_Sitemap::CACHE_KEY );
        $flush_url      = wp_nonce_url(
            admin_url( 'admin-post.php?action=simple_seo_flush_sitemap' ),
            'simple_seo_flush_sitemap'
        );
        $bulk_alt_url   = wp_nonce_url(
            admin_url( 'admin-post.php?action=simple_seo_bulk_fix_alt' ),
            'simple_seo_bulk_fix_alt'
        );

        $notice = isset( $_GET['sseo_notice'] ) ? sanitize_key( $_GET['sseo_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
        ?>
        <div class="wrap sseo-wrap">
            <h1><?php esc_html_e( 'Simple SEO – Sitemap', 'simple-seo' ); ?></h1>

            <?php if ( 'sitemap_flushed' === $notice ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Sitemap cache cleared successfully.', 'simple-seo' ); ?></p>
                </div>
            <?php elseif ( 'alt_fixed' === $notice ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <?php
                        printf(
                            /* translators: %d: number of images fixed */
                            esc_html__( '%d image(s) updated with ALT text.', 'simple-seo' ),
                            (int) ( $_GET['count'] ?? 0 ) // phpcs:ignore WordPress.Security.NonceVerification
                        );
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <h2><?php esc_html_e( 'XML Sitemap', 'simple-seo' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'Sitemap URL', 'simple-seo' ); ?></th>
                    <td>
                        <a href="<?php echo esc_url( $sitemap_url ); ?>" target="_blank">
                            <?php echo esc_html( $sitemap_url ); ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Cache Status', 'simple-seo' ); ?></th>
                    <td>
                        <?php if ( $cache_exists ) : ?>
                            <span style="color:green;">&#10003; <?php esc_html_e( 'Cached', 'simple-seo' ); ?></span>
                        <?php else : ?>
                            <span style="color:orange;">&#9888; <?php esc_html_e( 'Not cached (will be generated on next request)', 'simple-seo' ); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Flush Cache', 'simple-seo' ); ?></th>
                    <td>
                        <a href="<?php echo esc_url( $flush_url ); ?>" class="button">
                            <?php esc_html_e( 'Flush Sitemap Cache', 'simple-seo' ); ?>
                        </a>
                        <p class="description">
                            <?php esc_html_e( 'The sitemap is automatically refreshed when content changes. Use this only if needed.', 'simple-seo' ); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <hr>

            <h2><?php esc_html_e( 'Image SEO – Bulk ALT Fixer', 'simple-seo' ); ?></h2>
            <p><?php esc_html_e( 'Sets missing ALT text on all attachments using their title.', 'simple-seo' ); ?></p>
            <a href="<?php echo esc_url( $bulk_alt_url ); ?>" class="button button-secondary">
                <?php esc_html_e( 'Fix Missing ALT Text', 'simple-seo' ); ?>
            </a>
        </div>
        <?php
    }

    // ── Handlers ─────────────────────────────────────────────────────────────

    public function handle_flush_sitemap(): void {
        SimpleSEO_Helpers::require_capability();
        check_admin_referer( 'simple_seo_flush_sitemap' );

        delete_transient( SimpleSEO_Sitemap::CACHE_KEY );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'simple-seo-sitemap', 'sseo_notice' => 'sitemap_flushed' ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    public function handle_bulk_fix_alt(): void {
        SimpleSEO_Helpers::require_capability();
        check_admin_referer( 'simple_seo_bulk_fix_alt' );

        /** @var SimpleSEO_Image_SEO $image_seo */
        $image_seo = simple_seo()->get( 'image_seo' );
        $count     = $image_seo ? $image_seo->bulk_fix_alt() : 0;

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'simple-seo-sitemap', 'sseo_notice' => 'alt_fixed', 'count' => $count ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }
}
